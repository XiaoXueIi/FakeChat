
let config = {
    enabled: false,
    playerCount: 5,
    interval: 30
};

let messages = [];
let keywords = {};

// 伪造玩家相关变量
let fakePlayerTask = null;
let fakePlayerNames = [];

// 预设英文名库
const namePool = [
    "Steve", "Alex", "Herobrine", "Notch", "Jeb",
    "Dream", "Technoblade", "Grian", "Mumbo", "Philza",
    "Tom", "Jerry", "Mike", "John", "David",
    "Peter", "Jack", "Rose", "Lily", "Lucy",
    "Bob", "Alice", "Charlie", "Daniel", "Edward",
    "Frank", "George", "Henry", "Ivan", "Kevin",
    "Louis", "Mark", "Nick", "Oliver", "Paul",
    "Robert", "Sam", "Tony", "Victor", "William",
    "Anna", "Bella", "Cindy", "Diana", "Ella",
    "Fiona", "Grace", "Hannah", "Ivy", "Jane",
    "Kate", "Linda", "Mary", "Nancy", "Olivia"
];

const digits = "0123456789";

// 加载配置
function loadConfig() {
    try {
        const configStr = File.readFrom("./plugins/FakeChat/fakechat_config.json");
        if (configStr) {
            config = JSON.parse(configStr);
        }
    } catch(e) {
        logger.warn("读取 fakechat_config.json 失败，使用默认配置");
    }
}

// 加载语句库（备用）
function loadMessages() {
    try {
        const msgStr = File.readFrom("./plugins/FakeChat/fakechat_messages.json");
        if (msgStr) {
            messages = JSON.parse(msgStr);
        }
    } catch(e) {
        logger.warn("读取 fakechat_messages.json 失败");
        messages = [];
    }
}

// 默认基础词库
function getDefaultKeywords() {
    return {
        "你好|嗨|hello|hi|在吗": [
            "你好呀！",
            "嗨～",
            "Hello！",
            "在呢在呢！"
        ],
        "服务器|ip|地址": [
            "服务器地址是 play.example.com",
            "IP: play.example.com 端口: 19132"
        ],
        "菜单|cd|商店": [
            "输入 /menu 打开菜单",
            "/cd 查看个人菜单"
        ],
        "再见|拜拜|bye": [
            "拜拜！",
            "再见啦！",
            "下次见！"
        ],
        "谢谢|感谢": [
            "不客气！",
            "应该的！"
        ],
        "今天|天气": [
            "今天天气真好，适合挖矿。",
            "天气不错，出去走走吧。"
        ],
        "有人吗|在吗": [
            "有人有人！",
            "我在呢！"
        ],
        "挖矿|钻石": [
            "我刚刚挖到钻石了！",
            "今天挖矿运气不错。"
        ],
        "打龙|末影龙": [
            "有人一起打龙吗？",
            "末影龙好难打。"
        ],
        "晚安|睡了": [
            "晚安！",
            "明天见！"
        ]
    };
}

// 保存词库到文件
function saveKeywords() {
    try {
        File.writeTo("./plugins/FakeChat/keywords.json", JSON.stringify(keywords, null, 4));
        logger.info("词库文件已创建");
    } catch(e) {
        logger.error("保存词库文件失败: " + e);
    }
}

// 加载词库（失败时自动创建）
function loadKeywords() {
    try {
        const kwStr = File.readFrom("./plugins/FakeChat/keywords.json");
        if (kwStr) {
            keywords = JSON.parse(kwStr);
            logger.info(`词库加载成功，共 ${Object.keys(keywords).length} 个关键词规则`);
        } else {
            // 文件为空，创建默认词库
            logger.warn("keywords.json 为空，正在创建默认词库...");
            keywords = getDefaultKeywords();
            saveKeywords();
            logger.info(`默认词库已创建，共 ${Object.keys(keywords).length} 个关键词规则`);
        }
    } catch(e) {
        // 文件不存在或读取失败，创建默认词库
        logger.warn("读取 keywords.json 失败，正在创建默认词库...");
        keywords = getDefaultKeywords();
        saveKeywords();
        logger.info(`默认词库已创建，共 ${Object.keys(keywords).length} 个关键词规则`);
    }
}
// 保存配置
function saveConfig() {
    try {
        File.writeTo("./plugins/FakeChat/fakechat_config.json", JSON.stringify(config, null, 4));
    } catch(e) {
        logger.error("保存配置文件失败: " + e);
    }
}

// 生成伪造玩家名（英文名 + 4-7位数字）
function generateFakeName() {
    const baseName = namePool[Math.floor(Math.random() * namePool.length)];
    const digitCount = Math.floor(Math.random() * 4) + 4;
    let suffix = "";
    for (let i = 0; i < digitCount; i++) {
        suffix += digits[Math.floor(Math.random() * digits.length)];
    }
    return baseName + suffix;
}

// 刷新伪造玩家池
function refreshFakePlayers(count) {
    fakePlayerNames = [];
    const usedNames = new Set();
    
    for (let i = 0; i < count; i++) {
        let name = generateFakeName();
        while (usedNames.has(name)) {
            name = generateFakeName();
        }
        usedNames.add(name);
        fakePlayerNames.push(name);
    }
}

// 获取随机伪造玩家名
function getRandomFakeName() {
    if (fakePlayerNames.length === 0) {
        refreshFakePlayers(config.playerCount);
    }
    return fakePlayerNames[Math.floor(Math.random() * fakePlayerNames.length)];
}

// 从词库中获取随机消息（模拟玩家发言）
function getRandomMessageFromKeywords() {
    const allReplies = [];
    for (const replies of Object.values(keywords)) {
        if (Array.isArray(replies) && replies.length > 0) {
            allReplies.push(...replies);
        }
    }
    
    if (allReplies.length === 0) {
        // 词库为空时使用备用语句
        if (messages.length > 0) {
            return messages[Math.floor(Math.random() * messages.length)];
        }
        return "今天天气真好。";
    }
    
    return allReplies[Math.floor(Math.random() * allReplies.length)];
}

// 根据消息内容获取匹配的回复（模拟小沐晞的回复逻辑）
function getReplyForMessage(msg) {
    for (const [pattern, replies] of Object.entries(keywords)) {
        const regex = new RegExp(pattern, "i");
        if (regex.test(msg)) {
            return replies[Math.floor(Math.random() * replies.length)];
        }
    }
    return null;
}

// 计算延迟时间
function calculateDelay(message) {
    const chineseCount = (message.match(/[\u4e00-\u9fa5]/g) || []).length;
    const englishCount = (message.match(/[a-zA-Z0-9]/g) || []).length;
    const effectiveChars = chineseCount + Math.ceil(englishCount / 2);
    let delay = effectiveChars * 200;
    delay = Math.max(800, Math.min(4000, delay));
    return delay;
}

// 发送伪造消息（模拟真实对话）
function sendFakeMessage() {
    if (!config.enabled) return;
    
    const count = config.playerCount;
    // 随机1-3人发言
    const sendCount = Math.floor(Math.random() * 3) + 1;
    
    for (let i = 0; i < sendCount; i++) {
        const delay = i * 3000 + Math.floor(Math.random() * 2000);
        
        setTimeout(() => {
            const fakeName = getRandomFakeName();
            const message = getRandomMessageFromKeywords();
            
            // 伪造玩家发言
            mc.broadcast(`<${fakeName}> ${message}`);
            
            // 检查是否有其他伪造玩家回复（模拟对话）
            const reply = getReplyForMessage(message);
            if (reply && Math.random() < 0.6) {
                const replyDelay = calculateDelay(message) + 1000 + Math.random() * 2000;
                
                setTimeout(() => {
                    // 找一个不同的伪造玩家来回复
                    let replyName = getRandomFakeName();
                    while (replyName === fakeName && fakePlayerNames.length > 1) {
                        replyName = getRandomFakeName();
                    }
                    
                    mc.broadcast(`<${replyName}> ${reply}`);
                    
                    // 可能还有第三个人接话
                    if (Math.random() < 0.3) {
                        const reply2 = getReplyForMessage(reply);
                        if (reply2) {
                            setTimeout(() => {
                                let thirdName = getRandomFakeName();
                                while (thirdName === fakeName || thirdName === replyName) {
                                    thirdName = getRandomFakeName();
                                }
                                mc.broadcast(`<${thirdName}> ${reply2}`);
                            }, calculateDelay(reply) + 1000);
                        }
                    }
                }, replyDelay);
            }
        }, delay);
    }
}

// 启动伪造玩家任务
function startFakePlayer() {
    if (fakePlayerTask) {
        clearInterval(fakePlayerTask);
        fakePlayerTask = null;
    }
    
    if (config.enabled) {
        const interval = (config.interval || 30) * 1000;
        fakePlayerTask = setInterval(sendFakeMessage, interval);
        logger.info(`FakeChat 已启动，${config.playerCount}人，间隔${config.interval}秒`);
    }
}

// 停止伪造玩家任务
function stopFakePlayer() {
    if (fakePlayerTask) {
        clearInterval(fakePlayerTask);
        fakePlayerTask = null;
    }
    logger.info("FakeChat 已停止");
}

// 首次加载
loadConfig();
loadMessages();
loadKeywords();
refreshFakePlayers(config.playerCount);
startFakePlayer();

// 主命令

// 注册命令（所有玩家可输入，但只有管理员能执行）
mc.regPlayerCmd("fakechat", "FakeChat 伪造玩家聊天系统", (player, args) => {
    // 权限检查：只有 OP 才能使用
    if (!player.isOP()) {
        player.tell(`§c你没有权限使用此命令！`);
        return;
    }
    
    // 以下是原有的命令逻辑...
   
    const subCmd = args[0]?.toLowerCase();
    
    if (subCmd === "on") {
        config.enabled = true;
        startFakePlayer();
        player.tell(`§aFakeChat 已开启，${config.playerCount}人，间隔${config.interval}秒。`);
        saveConfig();
    } else if (subCmd === "off") {
        config.enabled = false;
        stopFakePlayer();
        player.tell(`§7FakeChat 已关闭。`);
        saveConfig();
    } else if (subCmd === "set") {
        const value = parseInt(args[1]);
        if (!isNaN(value) && value > 0 && value <= 20) {
            config.playerCount = value;
            refreshFakePlayers(value);
            if (config.enabled) {
                stopFakePlayer();
                startFakePlayer();
            }
            player.tell(`§a伪造玩家人数已设置为 ${value} 人。`);
            saveConfig();
        } else {
            player.tell(`§e用法: /fakechat set <1-20>`);
        }
    } else if (subCmd === "list") {
        player.tell(`§6==== 伪造玩家列表 (${fakePlayerNames.length}人) ====`);
        fakePlayerNames.forEach((name, i) => {
            player.tell(`§7${i+1}. §e${name}`);
        });
    } else if (subCmd === "now") {
        sendFakeMessage();
        player.tell(`§a已触发一次伪造玩家发言。`);
    } else if (subCmd === "reload") {
        loadConfig();
        loadMessages();
        loadKeywords();
        refreshFakePlayers(config.playerCount);
        stopFakePlayer();
        startFakePlayer();
        player.tell(`§aFakeChat 已重载，词库共 ${Object.keys(keywords).length} 个规则，${fakePlayerNames.length}人。`);
    } else {
        player.tell(`§6==== FakeChat 伪造玩家聊天 ====`);
        player.tell(`§e/fakechat on §7- 开启功能`);
        player.tell(`§e/fakechat off §7- 关闭功能`);
        player.tell(`§e/fakechat set <1-20> §7- 设置人数`);
        player.tell(`§e/fakechat list §7- 查看伪造玩家列表`);
        player.tell(`§e/fakechat now §7- 立即触发一次发言`);
        player.tell(`§e/fakechat reload §7- 重载配置和词库`);
        player.tell(`§7当前状态: ${config.enabled ? '§a开启' : '§7关闭'}，${config.playerCount}人，间隔${config.interval}秒`);
        player.tell(`§7词库规则: §e${Object.keys(keywords).length} §7个`);
    }
});

logger.info("FakeChat 伪造玩家聊天系统已加载");